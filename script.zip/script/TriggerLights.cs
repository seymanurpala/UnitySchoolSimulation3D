using UnityEngine;

public class TriggerLights : MonoBehaviour
{
    public Light odaIsigi; // sahnede bir ���k ata

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) // sadece oyuncu girince
        {
            odaIsigi.enabled = false; // ����� kapat
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            odaIsigi.enabled = true; // ����� geri a�
        }
    }
}
