using UnityEngine;
using System.Collections;  


public class PlayerScript : MonoBehaviour
{
    private Animator animator; // Animator referans�
    public float moveSpeed = 3f; // Hareket h�z�
    public int[,] map; // Okul haritas�

    void Start()
    {
        animator = GetComponentInChildren<Animator>(); // Animator'� al
    }

    // Hedefe hareket etmeye izin verilip verilmedi�ini kontrol eder
    public bool CanMoveTo(Vector3 targetPosition)
    {
        int x = Mathf.FloorToInt(targetPosition.x);
        int z = Mathf.FloorToInt(targetPosition.z);

        if (x >= 0 && z >= 0 && x < map.GetLength(0) && z < map.GetLength(1))
        {
            return map[x, z] == 0; // Ge�i� yap�labilir alan
        }
        return false; // Ge�i� yap�lamaz
    }

    public IEnumerator MoveTo(Vector3 target)
    {
        Vector3 direction = (target - transform.position).normalized;

        // Y�nl� animasyon i�in Speed ayarlan�yor
        animator.SetFloat("Speed", direction.magnitude);

        // Karakteri hareket y�n�ne d�nd�r
        if (direction != Vector3.zero)
        {
            Quaternion toRotation = Quaternion.LookRotation(direction, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, toRotation, 0.2f);
        }

        // Hareket bitene kadar ilerle
        while (Vector3.Distance(transform.position, target) > 0.05f)
        {
            transform.position = Vector3.MoveTowards(transform.position, target, moveSpeed * Time.deltaTime);

            // Hareket s�resince animasyonu g�ncelle
            animator.SetFloat("Speed", direction.magnitude);

            yield return null;
        }

        transform.position = target;

        // Hareketsiz animasyona ge�
        animator.SetFloat("Speed", 0f);
    }
}
