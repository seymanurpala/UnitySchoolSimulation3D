﻿using UnityEngine;

public class OkulSimulasyonu : MonoBehaviour
{
    public GameObject wallPrefab; // Duvar Prefabı
    public GameObject player; // Oyuncu karakteri
    private PlayerScript playerScript; // PlayerScript referansı
    const int xdim = 50;
    const int ydim = 100;
    public int[,] schoolMap = new int[xdim, ydim]; // 50x100 Matris

    void Start()
    {
        playerScript = player.GetComponent<PlayerScript>(); // PlayerScript referansını al
        LoadMapFromCSV(); // CSV dosyasından haritayı yükle
        BuildSchool(); // Duvarları oluştur
        PlacePlayer(); // Oyuncuyu yerleştir
    }

    void LoadMapFromCSV()
    {
        TextAsset textAsset = Resources.Load<TextAsset>("matrissss");

        if (textAsset == null)
        {
            Debug.LogError("CSV dosyası bulunamadı! Resources klasöründe 'matrissss.csv' olduğundan emin olun.");
            return;
        }

        string[] lines = textAsset.text.Split('\n');

        for (int x = 0; x < xdim && x < lines.Length; x++)
        {
            if (string.IsNullOrWhiteSpace(lines[x])) continue;

            string[] values = lines[x].Trim().Split(';');

            for (int z = 0; z < ydim && z < values.Length; z++)
            {
                if (int.TryParse(values[z], out int val) && (val == 0 || val == 1))
                {
                    schoolMap[x, z] = val;
                }
                else
                {
                    Debug.LogError($"Geçersiz veri: {values[z]} (Satır: {x}, Sütun: {z})");
                    schoolMap[x, z] = 0;
                }
            }
        }
    }

    void BuildSchool()
    {
        for (int x = 0; x < xdim; x++)
        {
            for (int z = 0; z < ydim; z++)
            {
                if (schoolMap[x, z] == 1)
                {
                    Vector3 position = new Vector3(x, 1.5f, z);
                    GameObject wall = Instantiate(wallPrefab, position, Quaternion.identity);
                    wall.transform.parent = this.transform;
                }
            }
        }
    }

    void PlacePlayer()
    {
        for (int x = 0; x < xdim; x++)
        {
            for (int z = 0; z < ydim; z++)
            {
                if (schoolMap[x, z] == 0)
                {
                    player.transform.position = new Vector3(x, 1.5f, z);
                    Debug.Log($"Oyuncu yerleştirildi: {x}, {z}");
                    return;
                }
            }
        }
    }
}
