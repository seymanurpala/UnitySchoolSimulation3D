using UnityEngine;
using System.Collections;


public class LevelManager : MonoBehaviour
{
    public GameObject player; // Oyuncu referans�
    public Transform targetPosition; // Hedef alan
    public float resetDelay = 2f; // Seviye ge�i�i i�in gecikme s�resi

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player) // E�er oyuncu hedefe ula�t�ysa
        {
            // Hedefe ula��ld���nda yap�lacak i�lemler
            Debug.Log("Hedefe Ula��ld�! Yeni seviyeye ge�iliyor...");

            // Bir s�re bekledikten sonra oyunu s�f�rlamak i�in bir coroutine ba�lat
            StartCoroutine(ResetGame());
        }
    }

    private IEnumerator ResetGame()
    {
        // Belirli bir s�re bekle (seviye ge�i�i i�in)
        yield return new WaitForSeconds(resetDelay);

        // Oyunun ba�lang�� noktas�na geri d�n
        player.transform.position = Vector3.zero; // Bu, oyuncuyu s�f�r noktas�na yerle�tirir

        // Burada oyunun di�er durumlar�n� s�f�rlayabilirsin (�rne�in puanlar, zamanlay�c�lar)
        Debug.Log("Yeni seviye ba�lat�ld�!");
    }
}

