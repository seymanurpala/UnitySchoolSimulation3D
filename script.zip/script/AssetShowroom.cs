using UnityEngine;
using UnityEngine.UI;

public class AssetShowroom : MonoBehaviour
{
    public Text assetInfoText; // Varl�k bilgisinin g�r�nece�i text
    public Button showButton;  // Buton

    // Varl�k bilgilerini g�stermek i�in bir fonksiyon
    public void ShowAssetInfo(string assetName, string assetDetails)
    {
        assetInfoText.text = "Asset Name: " + assetName + "\n" + "Details: " + assetDetails;
    }

    // Start fonksiyonu, buton t�klama i�levini ba�latacak
    void Start()
    {
        // Buton t�klama i�levini buradan ba�layaca��z
        showButton.onClick.AddListener(() => ShowAssetInfo("Cube", "This is a simple cube asset."));
    }
}
