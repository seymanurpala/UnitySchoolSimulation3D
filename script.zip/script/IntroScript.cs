using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;  // Text ve Button i�in bu k�t�phaneye ihtiyac�m�z var

public class IntroScene : MonoBehaviour
{
    public float introDuration = 5f;  // Tan�t�m ekran� s�resi (saniye olarak)
    public Text introText;            // Tan�t�m ekran� metni
    public Button skipButton;         // Tan�t�m ekran� atlama butonu

    void Start()
    {
        // Buton t�klama olay�n� ba�lama
        skipButton.onClick.AddListener(SkipIntro);

        // Tan�t�m ekran�n� belirledi�in s�re kadar g�sterdikten sonra MainMenu sahnesine ge�i� yap
        Invoke("LoadMainMenu", introDuration);

    }

    // Intro'yu atlamak i�in butona t�klanabilir
    void SkipIntro()
    {
        LoadMainMenu();  // Hemen MainMenu sahnesine ge�
    }

    // MainMenu sahnesine ge�i�
    void LoadMainMenu()
    {
        SceneManager.LoadScene("MainMenu");  // Buradaki ismi, sahnenin ismiyle uyumlu 
    }
}
