using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 3f; // Oyuncunun hareket h�z�
    private Animator animator; // Animator referans�
    private Rigidbody rb; // Rigidbody referans�

    void Start()
    {
        animator = GetComponent<Animator>(); // Animator bile�enini al
        rb = GetComponent<Rigidbody>(); // Rigidbody bile�enini al
    }

    void Update()
    {
        // Tu�larla hareket kontrol� (ASWD)
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 direction = new Vector3(horizontal, 0f, vertical).normalized;

        // Animasyon h�z� ayarlar�
        animator.SetFloat("Speed", direction.magnitude);

        if (direction.magnitude > 0.1f) // Hareket varsa
        {
            Vector3 move = direction * speed * Time.deltaTime;
            rb.MovePosition(transform.position + move); // Fiziksel hareket
        }
    }
}
