using UnityEngine;
using UnityEngine.AI;

public class PlayerAutoPatrol : MonoBehaviour
{
    public Transform[] hedefler;
    private int aktifHedef = 0;
    private NavMeshAgent agent;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        if (hedefler.Length > 0)
            agent.SetDestination(hedefler[aktifHedef].position);
    }

    void Update()
    {
        if (!agent.pathPending && agent.remainingDistance < 0.5f)
        {
            aktifHedef = (aktifHedef + 1) % hedefler.Length;
            agent.SetDestination(hedefler[aktifHedef].position);
        }
    }
}
