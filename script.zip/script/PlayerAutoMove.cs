using UnityEngine;
using UnityEngine.AI;

public class PlayerAutoMove : MonoBehaviour
{
    public Transform hedefNokta;
    private NavMeshAgent agent;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        if (hedefNokta != null)
        {
            agent.SetDestination(hedefNokta.position);
        }
    }
}
